public class IncrDemoMes {

    static final long NB_IT = 1000000000L; // 1 milliard
    static long cpt = 0L;
    static long durée = 0L;

    public static void main(String[] args) {
        int nbActivités = 3;
        int i = 0;
        long duréeMulti, duréeMono;
        Thread[] multi;

        if (args.length != 0) {
            nbActivités = Integer.parseInt (args[0]);
            if (nbActivités < 1) {
                System.out.println("Nb activités >= 1");
                System.exit (1);
            }
        }
        multi = new Thread[nbActivités];

        for (i = 0; i < nbActivités ; i++) {
            multi[i] = new Thread(new IncrémenteurMes(1),"t"+i);
            multi[i].start(); // try {Thread.sleep(1000);} catch (Exception e) {}
        }

        for (i = 0; i < nbActivités ; i++) {
            try {
                multi[i].join();
            }
            catch (Exception e) {
                System.out.println(e);
            }
        }
        duréeMulti = IncrDemoMes.durée/1000000L ;
        IncrDemoMes.durée = 0L;
        IncrDemoMes.cpt = 0L;
        Thread t=new Thread(new IncrémenteurMes(nbActivités),"T");
        t.start();
        try {
            t.join();
        }
        catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("Durée multi (ms) : " + duréeMulti);
        duréeMono = IncrDemoMes.durée/1000000L ;
        System.out.println("Durée mono (ms) : " + duréeMono);
        System.out.println("Surcoût (multi*nbactivités/mono) : " + 1.0*nbActivités*duréeMulti/duréeMono);
    }
}

class IncrémenteurMes implements Runnable {
    int mult;

    IncrémenteurMes(int fact) {
        mult=fact;
    }

    void incr() {
        for (long i = 0L; i < mult*IncrDemoMes.NB_IT; i++) {
            IncrDemoMes.cpt=+(i+1)/(i+1);
        }
    }

    public void run() {
        //System.out.println("Thread " + this.getName() + " part de : " + IncrDemoMes.cpt);
        long startTime = System.nanoTime();
        //System.out.println("Thread " + Thread.currentThread().getName() + " part de : " + startTime);
        incr();
        IncrDemoMes.durée = Math.max(IncrDemoMes.durée, System.nanoTime() - startTime);
        //System.out.println("Thread " + Thread.currentThread().getName() + " finit à : " +  IncrDemoMes.durée);
    }
}