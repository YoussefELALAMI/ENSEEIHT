Concurrence et cohérence : éléments de réponse
==============================================

Objectifs du TP
---------------
- pratique du test : 
	* concevoir les tests, réfléchir aux résultats attendus *avant* de réaliser les tests
	* élaborer des tests simples pour *expérimenter* directement/interactivement un comportement
- autonomie dans la construction des tests
- sur le contenu : aborder les problèmes de performances et de cohérence en programmation concurrente
	 
   
Exercices
---------
### Efficacité de la parallélisation
Il s'agit d'évaluer le gain de temps apporté par la décomposition d'un traitement 
en plusieurs threads.
On considère le traitement réalisé par la classe `IncrSeq` fournie dans l'archive, qui 
consiste en une boucle qui incrémente un compteur global. Le nombre important d'itérations 
est destiné à permettre des mesures significatives, mais va nécessiter l'emploi d'entiers
longs.

Comparer le temps d'exécution de l'itération totale avec le temps d'exécution d'une 
application où N threads effectuent chacun 1/N ème de l'itération, N étant un paramètre
fourni au lancement de l'application. 

- Quel résultat « naïf » peut-on a priori espérer ?
- Evaluer le surcoût induit par la gestion des threads,
en fonction de N (en faisant varier N entre 1 et 30, sans nécessairement prendre toutes
les valeurs :) ).
- Interpréter ce résultat et conclure.

*Un exemple d'exécution de IncrDemoMes, sur ma machine (6 cœurs, dont semble-t-il 5 pour les applications)*

	[ps3:Corrigés/TP1/TP1A - Concurrence et cohérence] % java IncrDemoMes
	Durée multi (ms) : 555
	Durée mono (ms) : 1570
	Surcoût (multi*nbactivités/mono) : 1.0605095541401275
	
	[ps3:Corrigés/TP1/TP1A - Concurrence et cohérence] % java IncrDemoMes 5
	Durée multi (ms) : 576
	Durée mono (ms) : 2612
	Surcoût (multi*nbactivités/mono) : 1.1026033690658499
	
	[ps3:Corrigés/TP1/TP1A - Concurrence et cohérence] % java IncrDemoMes 10
	Durée multi (ms) : 1112
	Durée mono (ms) : 5232
	Surcoût (multi*nbactivités/mono) : 2.125382262996942
	
	[ps3:Corrigés/TP1/TP1A - Concurrence et cohérence] % java IncrDemoMes 15
	Durée multi (ms) : 1828
	Durée mono (ms) : 7843
	Surcoût (multi*nbactivités/mono) : 3.4961111819456843
	
	[ps3:Corrigés/TP1/TP1A - Concurrence et cohérence] % java IncrDemoMes 20
	Durée multi (ms) : 2373
	Durée mono (ms) : 10455
	Surcoût (multi*nbactivités/mono) : 4.539454806312769
	
	[ps3:Corrigés/TP1/TP1A - Concurrence et cohérence] % java IncrDemoMes 25
	Durée multi (ms) : 2996
	Durée mono (ms) : 13059
	Surcoût (multi*nbactivités/mono) : 5.735508078719657
	
	[ps3:Corrigés/TP1/TP1A - Concurrence et cohérence] % java IncrDemoMes 30
	Durée multi (ms) : 3589
	Durée mono (ms) : 15660
	Surcoût (multi*nbactivités/mono) : 6.875478927203065
	
*Intuitivement, on peut s'attendre à ce que le temps d'exécution soit inversement 
proportionnel au nombre de threads, ce qui est le cas, avec un surcoût de 10% ou moins, 
tant que le nombre de threads est inférieur au nombre de cœurs physiques disponibles (5 ici).
Ensuite, l'augmentation du nombre de threads n'apporte rien (mais ne coûte pas grand chose
non plus), puisque le ratio entre le temps monoactivité et le temps multiactivités reste
sensiblement égal au nombre de cœurs physiques.*

### Coût de la cohérence
Vérifier la correction des résultats obtenus par l'application précédente. Pour cela,
 chaque thread affichera la valeur du compteur avant de démarrer sa (fraction de) boucle,
 ainsi que la valeur du compteur après.
 
- Quelles seront *a priori* les valeurs affichées dans le cas où il n'y a pas préemption 
 du processeur entre threads ?
 
 *Sans préemption, les threads, qui réalisent un calcul pur, s'exécuteront l'un après l'autre,
et les valeurs affichées seront des valeurs successives.*

- Quelles seront *a priori* les valeurs affichées dans le cas où la gestion des activités
 partage le temps processeur par quantum de temps entre threads ?
 
*Avec préemption, la valeur de départ de chacun des threads est indépendante : un thread
  lit la valeur courante du compteur, telle qu'elle a été établie par les autres threads
  en cours d'exécution. Et c'est là tout le problème.*
  
- Quelle est la politique effectivement suivie par la JVM utilisée pour le test ?
- La valeur finale du compteur devrait être égale au nombre total d'itérations. Vérifier
 que ce n'est pas le cas avec la version actuelle, et expliquer pourquoi.

*Cf supra*

- Afin de garantir la cohérence du résultat final, on effectue les incrémentations du
 compteur en exclusion mutuelle, en plaçant l'incrémentation dans un bloc `synchronized`,
 associé à un objet global quelconque. (Déclarer par exemple un attribut 
 `static Object mutex = new Object();` dans la classe principale). Vérifier que le résultat
 est maintenant effectivement correct, et évaluer le coût de l'utilisation de ce mécanisme.
   * en plaçant uniquement l'incrémentation de la boucle interne dans le bloc `synchronized` 
   * en plaçant la boucle interne dans le bloc `synchronized` 
- La correction du résultat est-elle garantie a priori si l'on utilise un objet de la classe
 `java.util.concurrent.atomic.AtomicLong` pour le compteur ? Argumenter, puis vérifier 
 cet a priori. Evaluer le coût de l'utilisation de ce mécanisme
 - La correction du résultat est-elle garantie a priori si l'on déclare le compteur
 comme  `volatile` ? Argumenter, puis vérifier cet a priori. Evaluer le coût de 
 l'utilisation de ce mécanisme.
 - Conclure globalement sur les conditions d'utilisation (ou pas) de ces différents mécanismes.

**Remarques préalables** 

- La boucle principale comporte mille itérations, dont chacune consiste en une boucle d'un
millions d'itérations, suivie d'une pause (en ms) (modélisant un calcul sans conflits).
- Le test prend deux paramètres : le nombre d'activités et la durée de la pause, ou aucun
(auquel cas les valeurs par défaut sont 3 (activités) et 100 (ms)
- La principale difficulté dans les mesures vient des mécanismes d'optimisation de la JVM :

	* utilisation de caches (que l'on essaie d'inhiber par l'appel à Thread.sleep, 
	ou l'utilisation de `volatile`)
	* optimisation et compilation à la volée  (que l'on essaie d'inhiber par l'appel
	 à Thread.sleep et par une incrémentation un peu moins évidente (+j/j au lieu de +1 ou ++)
	 
 La JVM est effet vraiment efficace, au point que sans inhibition, l'itération monoactivité
peut être significativement plus rapide que l'exécution multiactivités, ce qui n'est
pas forcément souhaitable dans la perspective présente...
	 
**Commentaires sur l'exécution**

L'exécution est faite avec les valeurs par défaut : 3 activités, pauses de 100ms.
Pour ce test, le temps de pause cumulé pour une activité est donc de 100s (1000*100ms). La
soustraction des temps de pause permet d'avoir une idée du coût et de l'efficacité 
intrinsèques des mécanismes.
	 
	[ps3:Corrigés/TP1/TP1A - Concurrence et cohérence] % java IncrDemoSync
    Durée exécution mono : 311789

	Thread t0 part de : 0
	Thread t1 part de : 0
	Thread t2 part de : 913
	Thread t1 finit à : 1233349588
	Thread t0 finit à : 1233349588
	Thread t2 finit à : 1233349588
	Durée exécution non synchronisée (ms): 104094

	Thread t0 part de : 0
	Thread t1 part de : 0
	Thread t2 part de : 688
	Thread t0 finit à : 1000000228
	Thread t2 finit à : 2000000039
	Thread t1 finit à : 3000000000
	Durée exécution synchronisée (ms): 311940

	Thread t0 part de : 0
	Thread t1 part de : 0
	Thread t2 part de : 217
	Thread t1 finit à : 2918391445
	Thread t2 finit à : 2935001685
	Thread t0 finit à : 3000000000
	Durée exécution synchronisée grain très fin (ms): 171699

	Thread t0 part de : 0
	Thread t1 part de : 0
	Thread t2 part de : 1499
	Thread t0 finit à : 3000000000
	Thread t2 finit à : 3000000000
	Thread t1 finit à : 3000000000
	Durée exécution synchronisée à grain fin (ms): 104185

	Thread t0 part de : 0
	Thread t2 part de : 0
	Thread t1 part de : 0
	Thread t0 finit à : 2985000000
	Thread t2 finit à : 2999000000
	Thread t1 finit à : 3000000000
	Durée exécution synchronisée atomique (ms): 113996
	
	Thread t0 part de : 0
	Thread t1 part de : 0
	Thread t2 part de : 602
	Thread t1 finit à : 2369037995
	Thread t0 finit à : 2373345600
	Thread t2 finit à : 2375342243
	Durée exécution volatile (ms): 127368
	
- L'exécution monoactivité sert de référence (312s)
- L'exécution non synchronisée est bien (approximativement) trois fois plus rapide (104s), et il
est clair que le résultat final n'est pas correct (ce devrait être 3 000 000 000). On voit
aussi que t2 part avec un petit décalage, mais pas de 1 000 000 000.
- L'exécution synchronisée (par un verrou global) a sensiblement le même temps d'exécution
que l'exécution monoactivité, ce qui est cohérent, et aboutit au résultat correct, ce qui
est rassurant. On peut noter que t2 est partie avec un petit décalage. On peut noter aussi
que les valeurs intermédiaires affichées par t0 et t2 ne sont pas exactement ce qu'elles
devraient être, ce qui est normal, car la lecture et l'affichage de cette valeur se font
*après* que t0 et t2 aient libéré leur verrou : le compteur aura donc avancé légèrement. 
Par contre, la dernière valeur doit être exacte, et c'est le cas.
- La synchronisation à grain très fin (au niveau de l'incrémentation) donne un résultat
correct, et améliore les temps d'exécution par rapport à l'exécution monoactivité (172s vs
312s), mais représente un surcoût très sensible par rapport à l'exécution non synchronisée
(104s), surtout si l'on retire les temps de pause (100s).
- La synchronisation à grain fin (au niveau de l'itération interne) donne un résultat
correct, et des temps équivalents à l'exécution non synchronisée (104s), ce qui devrait
satisfaire Patrick :)
- L'utilisation de variables atomiques donne aussi un résultat correct, avec un temps d'exécution
(114s) du même ordre, mais un peu supérieur que pour la synchronisation à grain.
- L'utilisation de variables volatiles donne un résultat erroné, avec un temps d'exécution
(127s) plutôt élevé par rapport à la synchronisation à grain fin, surtout si l'on retire
 les temps de pause (100s).	

### Schéma producteurs consommateurs
La classe PCA fournie dans l'archive est une implémentation du schéma 
producteur/consommateur, pour un unique producteur et un unique consommateur. L'algorithme
semble correct, et pourtant... le test montre un comportement incorrect. Expliquez et rectifiez le code en conséquence.

*L'exécution devrait bloquer après quelques itérations. La cause est liée à l'utilisation
de caches par les deux activités, qui aboutit à une incohérence entre les valeurs de cache.
Le remède le plus simple est de déclarer volatile les variables dépôt et retrait. Cela
fonctionne a priori de par la structure du problème (un écrivain par variable), mais en
 cas de doute il est toujours possible d'utiliser des variables atomiques ;)*