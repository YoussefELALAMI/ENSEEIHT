// V1.1 : sans généricité, mais avec deux paramètres :) PM 25/09/16
import java.util.concurrent.atomic.AtomicLong;

interface Incrémenteur extends Runnable{
	void incr();
}

public class IncrDemoSync {

	static long cpt = 0L;
	static volatile long cptV = 0L;
	static AtomicLong cptA = new AtomicLong(0L);
	static final long NB_IT = 1000L;
	static final long NB_IT_INTERNES = 1000000L;
	static long Attente_ms = 100L;
	static final int Attente_nano = 0;
	static Thread[] activités;
	static Object mutex = new Object();

	static void lancer(int nbA, Incrémenteur r) {
		cpt = 0L;
		cptA.set(0L);
		cptV = 0L;
		for (int i = 0; i < nbA ; i++) {
			try {
				IncrDemoSync.activités[i] = new Thread(r,"t"+i);
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
			IncrDemoSync.activités[i].start();
		}
	}

	static void finir() {
		for (int i = 0; i < IncrDemoSync.activités.length ; i++) {
			try {
				IncrDemoSync.activités[i].join();
			}
			catch (InterruptedException e)
			{
				System.out.println(e);
			}
		}
	}

	public static void main(String[] args) {
		int nbActivités = 3;
		int i = 0;
		long départ, fin;
		// affihcher les nombre des processeurs disponibles pour java
		System.out.println("nombre des processeurs disponibles " + Runtime.getRuntime().availableProcessors());
		if (args.length == 2) {
			try {
				nbActivités = Integer.parseInt (args[0]);
				Attente_ms = Integer.parseInt (args[1]);
			}
			catch (NumberFormatException nfx) {
				Attente_ms = 0;
			}
			if ((nbActivités < 1) || (Attente_ms < 1)) {
				System.out.println("Usage : IncrDemoSeq <Nb activités> <durée pause (ms)>,"
						+"avec Nb activités >= 1 et <durée pause >= 1");
				System.exit (1);
			}
		} else {
			System.out.println("Nb d'arguments ≠ 2. Exécution avec 3 activités et 100 ms de pause");
		}

		activités = new Thread[nbActivités];



		// version séquentielle
		départ = System.nanoTime();
		for (long li = 0; li < nbActivités*IncrDemoSync.NB_IT; li++) {
			for (long j = 1; j<=IncrDemoSync.NB_IT_INTERNES; j++) {
				IncrDemoSync.cpt=IncrDemoSync.cpt+j/j;
			}
			try {
				Thread.sleep(IncrDemoSync.Attente_ms, IncrDemoSync.Attente_nano);
			}
			catch (InterruptedException ie)
			{
				System.out.println("InterruptedException : " + ie);
			}
		}
		fin = System.nanoTime();
		System.out.println("Durée exécution mono : " + (fin-départ)/1000000L);
		System.out.println();
		// fin version séquentielle

		départ = System.nanoTime();
		lancer(nbActivités, new IncrémenteurNonSync());
		finir();
		fin = System.nanoTime();
		System.out.println("Durée exécution non synchronisée (ms): " + (fin-départ)/1000000L);
		System.out.println();

		départ = System.nanoTime();
		lancer(nbActivités,new IncrémenteurSync());
		finir();
		fin = System.nanoTime();
		System.out.println("Durée exécution synchronisée (ms): " + (fin-départ)/1000000L);
		System.out.println();

		départ = System.nanoTime();
		lancer(nbActivités,new IncrémenteurSyncExtrafin());
		finir();
		fin = System.nanoTime();
		System.out.println("Durée exécution synchronisée grain très fin (ms): " + (fin-départ)/1000000L);
		System.out.println();

		départ = System.nanoTime();
		lancer(nbActivités,new IncrémenteurSyncFin());
		finir();
		fin = System.nanoTime();
		System.out.println("Durée exécution synchronisée à grain fin (ms): " + (fin-départ)/1000000L);
		System.out.println();

		départ = System.nanoTime();
		lancer(nbActivités,new IncrémenteurAtomique());
		finir();
		fin = System.nanoTime();
		System.out.println("Durée exécution synchronisée atomique (ms): " + (fin-départ)/1000000L);
		System.out.println();

		départ = System.nanoTime();
		lancer(nbActivités,new IncrémenteurVolatile());
		finir();
		fin = System.nanoTime();
		System.out.println("Durée exécution volatile (ms): " + (fin-départ)/1000000L);
		System.out.println();

	}
}

class IncrémenteurNonSync implements Runnable, Incrémenteur {


	// cette version génère des valeurs incorrecte à cause d'accès simultanné au compteur.
	public void incr() {
		for (long i = 0L; i < IncrDemoSync.NB_IT; i++) {
			for (long j = 1; j<=IncrDemoSync.NB_IT_INTERNES; j++) {
				IncrDemoSync.cpt=IncrDemoSync.cpt+j/j;
			}
			try {
				Thread.sleep(IncrDemoSync.Attente_ms, IncrDemoSync.Attente_nano);
			}
			catch (InterruptedException ie)
			{
				System.out.println("InterruptedException : " + ie);
			}
		}
	}

	public void run() {
		System.out.println("Thread " + Thread.currentThread().getName() + " part de : " + IncrDemoSync.cpt);
		this.incr();
		System.out.println("Thread " + Thread.currentThread().getName() + " finit à : " + IncrDemoSync.cpt);
	}
}

class IncrémenteurSync implements Incrémenteur {

	// ici on rajoute un verrou pour avoir un résultat correct de l'incrémentation du compteur

	public void incr() {
		System.out.println("Le compteur avant Sync est égale à : " + IncrDemoMes.cpt);
		synchronized (IncrDemoSync.mutex) {
			for (int i = 0; i < IncrDemoSync.NB_IT; i++) {
				for (long j = 1; j<=IncrDemoSync.NB_IT_INTERNES; j++) {
					IncrDemoSync.cpt=IncrDemoSync.cpt+j/j;
				}
				try {
					Thread.sleep(IncrDemoSync.Attente_ms, IncrDemoSync.Attente_nano);
				}
				catch (InterruptedException ie)
				{
					System.out.println("InterruptedException : " + ie);
				}

			}
		}

		System.out.println("Le compteur après Sync est égale à : " + IncrDemoMes.cpt);
	}

	public void run() {
		System.out.println("Thread " +
				Thread.currentThread().getName() + " part de : " + IncrDemoSync.cpt);
		this.incr();
		System.out.println("Thread " + Thread.currentThread().getName() +
				" finit à : " + IncrDemoSync.cpt);
	}
}

class IncrémenteurSyncExtrafin implements Incrémenteur {

	public void incr() {
		for (int i = 0; i < IncrDemoSync.NB_IT; i++) {
			for (long j = 1; j<=IncrDemoSync.NB_IT_INTERNES; j++)  {

				// plaçant uniquement l'incrémentation de la boucle interne dans le bloc `synchronized`
				synchronized (IncrDemoSync.mutex)  {
					IncrDemoSync.cpt=IncrDemoSync.cpt+j/j;
				}
			}
			try {
				Thread.sleep(IncrDemoSync.Attente_ms, IncrDemoSync.Attente_nano);
			}
			catch (InterruptedException ie)
			{
				System.out.println("InterruptedException : " + ie);
			}


		}
	}

	public void run() {
		System.out.println("Thread " +
				Thread.currentThread().getName() + " part de : " + IncrDemoSync.cpt);
		this.incr();
		System.out.println("Thread " + Thread.currentThread().getName() +
				" finit à : " + IncrDemoSync.cpt);
	}
}

class IncrémenteurSyncFin implements Incrémenteur {

	public void incr() {
		for (int i = 0; i < IncrDemoSync.NB_IT; i++) {

			// plaçant la boucle interne dans le bloc `synchronized`
			synchronized (IncrDemoSync.mutex) {
				for (long j = 1; j<=IncrDemoSync.NB_IT_INTERNES; j++) {
					IncrDemoSync.cpt=IncrDemoSync.cpt+j/j;
				}
			}
			try {
				Thread.sleep(IncrDemoSync.Attente_ms, IncrDemoSync.Attente_nano);
			}
			catch (InterruptedException ie)
			{
				System.out.println("InterruptedException : " + ie);
			}


		}
	}

	public void run() {
		System.out.println("Thread " +
				Thread.currentThread().getName() + " part de : " + IncrDemoSync.cpt);
		this.incr();
		System.out.println("Thread " +
				Thread.currentThread().getName() + " finit à : " + IncrDemoSync.cpt);
	}
}

class IncrémenteurAtomique implements Incrémenteur {

	public void incr() {
		for (int i = 0; i < IncrDemoSync.NB_IT; i++) {
			for (long j = 1; j<=IncrDemoSync.NB_IT_INTERNES; j++) {
				IncrDemoSync.cptA.incrementAndGet();
			}

			try {
				Thread.sleep(IncrDemoSync.Attente_ms, IncrDemoSync.Attente_nano);
			}
			catch (InterruptedException ie)
			{
				System.out.println("InterruptedException : " + ie);
			}

		}
	}

	public void run() {
		System.out.println("Thread "
				+ Thread.currentThread().getName() + " part de : " + IncrDemoSync.cptA.get());
		this.incr();
		System.out.println("Thread "
				+ Thread.currentThread().getName() + " finit à : " + IncrDemoSync.cptA.get());
	}
}

class IncrémenteurVolatile implements Incrémenteur {

	public void incr() {
		for (int i = 0; i < IncrDemoSync.NB_IT; i++) {
			for (long j = 1; j<=IncrDemoSync.NB_IT_INTERNES; j++) {
				IncrDemoSync.cptV=IncrDemoSync.cptV+j/j;
			}
			try {
				Thread.sleep(IncrDemoSync.Attente_ms, IncrDemoSync.Attente_nano);
			}
			catch (InterruptedException ie)
			{
				System.out.println("InterruptedException : " + ie);
			}

		}
	}

	public void run() {
		System.out.println("Thread "
				+ Thread.currentThread().getName() + " part de : " + IncrDemoSync.cptV);
		this.incr();
		System.out.println("Thread "
				+ Thread.currentThread().getName() + " finit à : " + IncrDemoSync.cptV);
	}
}