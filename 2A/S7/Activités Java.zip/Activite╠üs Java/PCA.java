public class PCA {

    static final int N = 10;
    static volatile  int dépôt = 0;
    static volatile int retrait = 0;
    static char [] tampon = new char[N];
    static char [] val = {'a','b','c','d','e','f'};

    public static void main(String[] args) {
        Thread t1 = new Thread(new Producteur());
        Thread t2 = new Thread(new Consommateur());
        t1.start();
        t2.start(); 
    }
}

class Producteur implements Runnable {
    public void run() {
     for (;;) {
     	System.out.println("production...");
     	while (PCA.dépôt-PCA.retrait==PCA.N) {}
     	System.out.println("PCA.dépôt "+  PCA.val[PCA.dépôt/PCA.val.length % PCA.val.length]);
		PCA.tampon[PCA.dépôt%PCA.N] = PCA.val[PCA.dépôt/PCA.val.length % PCA.val.length];
      	PCA.dépôt++;
      	System.out.println("fait");
       }
    }
}
class Consommateur implements Runnable {
    public void run() {
    char item;
     for (;;) {
     	System.out.println("repos...");
     	while (PCA.dépôt==PCA.retrait) {}
     	System.out.println("PCA.retrait");
		item=PCA.tampon[PCA.retrait%PCA.N];
      	PCA.retrait++;
      	System.out.println("consommation "+item);
       }
    }
}