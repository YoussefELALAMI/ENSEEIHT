
package org.mule.module.magento.adapters;

import org.mule.api.Capabilities;
import org.mule.api.Capability;


/**
 * A <code>MagentoCloudConnectorCapabilitiesAdapter</code> is a wrapper around {@link org.mule.module.magento.MagentoCloudConnector } that implements {@link org.mule.api.Capabilities} interface.
 * 
 */
public class MagentoCloudConnectorCapabilitiesAdapter
    extends org.mule.module.magento.MagentoCloudConnector
    implements Capabilities
{


    /**
     * Returns true if this module implements such capability
     * 
     */
    public boolean isCapableOf(Capability capability) {
        if (capability == Capability.LIFECYCLE_CAPABLE) {
            return true;
        }
        return false;
    }

}
