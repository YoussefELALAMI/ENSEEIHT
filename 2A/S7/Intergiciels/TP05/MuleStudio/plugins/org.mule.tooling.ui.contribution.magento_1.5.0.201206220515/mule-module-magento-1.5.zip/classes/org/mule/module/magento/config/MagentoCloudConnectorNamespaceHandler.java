
package org.mule.module.magento.config;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;


/**
 * Registers bean definitions parsers for handling elements in <code>http://www.mulesoft.org/schema/mule/magento</code>.
 * 
 */
public class MagentoCloudConnectorNamespaceHandler
    extends NamespaceHandlerSupport
{


    /**
     * Invoked by the {@link DefaultBeanDefinitionDocumentReader} after construction but before any custom elements are parsed. 
     * @see NamespaceHandlerSupport#registerBeanDefinitionParser(String, BeanDefinitionParser)
     * 
     */
    public void init() {
        registerBeanDefinitionParser("config", new MagentoCloudConnectorConfigDefinitionParser());
        registerBeanDefinitionParser("add-order-shipment-comment", new AddOrderShipmentCommentDefinitionParser());
        registerBeanDefinitionParser("add-order-shipment-track", new AddOrderShipmentTrackDefinitionParser());
        registerBeanDefinitionParser("cancel-order", new CancelOrderDefinitionParser());
        registerBeanDefinitionParser("create-order-shipment", new CreateOrderShipmentDefinitionParser());
        registerBeanDefinitionParser("get-order", new GetOrderDefinitionParser());
        registerBeanDefinitionParser("get-order-invoice", new GetOrderInvoiceDefinitionParser());
        registerBeanDefinitionParser("get-order-shipment-carriers", new GetOrderShipmentCarriersDefinitionParser());
        registerBeanDefinitionParser("get-order-shipment", new GetOrderShipmentDefinitionParser());
        registerBeanDefinitionParser("hold-order", new HoldOrderDefinitionParser());
        registerBeanDefinitionParser("list-orders", new ListOrdersDefinitionParser());
        registerBeanDefinitionParser("list-orders-invoices", new ListOrdersInvoicesDefinitionParser());
        registerBeanDefinitionParser("list-orders-shipments", new ListOrdersShipmentsDefinitionParser());
        registerBeanDefinitionParser("delete-order-shipment-track", new DeleteOrderShipmentTrackDefinitionParser());
        registerBeanDefinitionParser("add-order-comment", new AddOrderCommentDefinitionParser());
        registerBeanDefinitionParser("unhold-order", new UnholdOrderDefinitionParser());
        registerBeanDefinitionParser("create-order-invoice", new CreateOrderInvoiceDefinitionParser());
        registerBeanDefinitionParser("add-order-invoice-comment", new AddOrderInvoiceCommentDefinitionParser());
        registerBeanDefinitionParser("capture-order-invoice", new CaptureOrderInvoiceDefinitionParser());
        registerBeanDefinitionParser("void-order-invoice", new VoidOrderInvoiceDefinitionParser());
        registerBeanDefinitionParser("cancel-order-invoice", new CancelOrderInvoiceDefinitionParser());
        registerBeanDefinitionParser("create-customer-address", new CreateCustomerAddressDefinitionParser());
        registerBeanDefinitionParser("create-customer", new CreateCustomerDefinitionParser());
        registerBeanDefinitionParser("delete-customer", new DeleteCustomerDefinitionParser());
        registerBeanDefinitionParser("delete-customer-address", new DeleteCustomerAddressDefinitionParser());
        registerBeanDefinitionParser("get-customer", new GetCustomerDefinitionParser());
        registerBeanDefinitionParser("get-customer-address", new GetCustomerAddressDefinitionParser());
        registerBeanDefinitionParser("list-customer-addresses", new ListCustomerAddressesDefinitionParser());
        registerBeanDefinitionParser("list-customer-groups", new ListCustomerGroupsDefinitionParser());
        registerBeanDefinitionParser("list-customers", new ListCustomersDefinitionParser());
        registerBeanDefinitionParser("update-customer", new UpdateCustomerDefinitionParser());
        registerBeanDefinitionParser("update-customer-address", new UpdateCustomerAddressDefinitionParser());
        registerBeanDefinitionParser("list-stock-items", new ListStockItemsDefinitionParser());
        registerBeanDefinitionParser("update-stock-item", new UpdateStockItemDefinitionParser());
        registerBeanDefinitionParser("list-directory-countries", new ListDirectoryCountriesDefinitionParser());
        registerBeanDefinitionParser("list-directory-regions", new ListDirectoryRegionsDefinitionParser());
        registerBeanDefinitionParser("add-product-link", new AddProductLinkDefinitionParser());
        registerBeanDefinitionParser("create-product-attribute-media", new CreateProductAttributeMediaDefinitionParser());
        registerBeanDefinitionParser("delete-product-attribute-media", new DeleteProductAttributeMediaDefinitionParser());
        registerBeanDefinitionParser("delete-product-link", new DeleteProductLinkDefinitionParser());
        registerBeanDefinitionParser("get-product-attribute-media", new GetProductAttributeMediaDefinitionParser());
        registerBeanDefinitionParser("get-catalog-current-store-view", new GetCatalogCurrentStoreViewDefinitionParser());
        registerBeanDefinitionParser("update-category-attribute-store-view", new UpdateCategoryAttributeStoreViewDefinitionParser());
        registerBeanDefinitionParser("list-category-attributes", new ListCategoryAttributesDefinitionParser());
        registerBeanDefinitionParser("list-category-attribute-options", new ListCategoryAttributeOptionsDefinitionParser());
        registerBeanDefinitionParser("list-product-attribute-media", new ListProductAttributeMediaDefinitionParser());
        registerBeanDefinitionParser("list-product-attribute-media-types", new ListProductAttributeMediaTypesDefinitionParser());
        registerBeanDefinitionParser("list-product-attribute-options", new ListProductAttributeOptionsDefinitionParser());
        registerBeanDefinitionParser("list-product-attributes", new ListProductAttributesDefinitionParser());
        registerBeanDefinitionParser("list-product-attribute-sets", new ListProductAttributeSetsDefinitionParser());
        registerBeanDefinitionParser("list-product-attribute-tier-prices", new ListProductAttributeTierPricesDefinitionParser());
        registerBeanDefinitionParser("list-product-link", new ListProductLinkDefinitionParser());
        registerBeanDefinitionParser("list-product-link-attributes", new ListProductLinkAttributesDefinitionParser());
        registerBeanDefinitionParser("list-product-link-types", new ListProductLinkTypesDefinitionParser());
        registerBeanDefinitionParser("list-product-types", new ListProductTypesDefinitionParser());
        registerBeanDefinitionParser("update-product-attribute-media", new UpdateProductAttributeMediaDefinitionParser());
        registerBeanDefinitionParser("update-product-attribute-tier-price", new UpdateProductAttributeTierPriceDefinitionParser());
        registerBeanDefinitionParser("update-product-link", new UpdateProductLinkDefinitionParser());
        registerBeanDefinitionParser("list-category-products", new ListCategoryProductsDefinitionParser());
        registerBeanDefinitionParser("add-category-product", new AddCategoryProductDefinitionParser());
        registerBeanDefinitionParser("create-category", new CreateCategoryDefinitionParser());
        registerBeanDefinitionParser("delete-category", new DeleteCategoryDefinitionParser());
        registerBeanDefinitionParser("get-category", new GetCategoryDefinitionParser());
        registerBeanDefinitionParser("list-category-levels", new ListCategoryLevelsDefinitionParser());
        registerBeanDefinitionParser("move-category", new MoveCategoryDefinitionParser());
        registerBeanDefinitionParser("delete-category-product", new DeleteCategoryProductDefinitionParser());
        registerBeanDefinitionParser("get-category-tree", new GetCategoryTreeDefinitionParser());
        registerBeanDefinitionParser("update-category", new UpdateCategoryDefinitionParser());
        registerBeanDefinitionParser("update-category-product", new UpdateCategoryProductDefinitionParser());
        registerBeanDefinitionParser("list-inventory-stock-items", new ListInventoryStockItemsDefinitionParser());
        registerBeanDefinitionParser("update-inventory-stock-item", new UpdateInventoryStockItemDefinitionParser());
        registerBeanDefinitionParser("create-product", new CreateProductDefinitionParser());
        registerBeanDefinitionParser("delete-product", new DeleteProductDefinitionParser());
        registerBeanDefinitionParser("get-product-special-price", new GetProductSpecialPriceDefinitionParser());
        registerBeanDefinitionParser("get-product", new GetProductDefinitionParser());
        registerBeanDefinitionParser("list-products", new ListProductsDefinitionParser());
        registerBeanDefinitionParser("update-product-special-price", new UpdateProductSpecialPriceDefinitionParser());
        registerBeanDefinitionParser("update-product", new UpdateProductDefinitionParser());
    }

}
