/*
 * $Id: TransactionConfig.java 23961 2012-03-07 16:48:42Z pablo.lagreca $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package org.mule.api.transaction;

import org.mule.transaction.constraints.ConstraintFilter;

/**
 * <code>TransactionConfig</code> defines transaction configuration for a
 * transactional endpoint.
 */
public interface TransactionConfig
{
    /** 
     * Whether there is a transaction available or not, ignore it 
     * <p>
     * J2EE: NotSupported
     */
    byte ACTION_NONE = 0;

    /** 
     * Will ensure that a new transaction is created for each invocation 
     * <p>
     * J2EE RequiresNew
     */
    byte ACTION_ALWAYS_BEGIN = 1;

    /** 
     * Will begin a new transaction if no transaction is already present 
     * <p>
     * J2EE: Required
     */
    byte ACTION_BEGIN_OR_JOIN = 2;

    /** 
     * There must always be a transaction present for the invocation 
     * <p>
     * J2EE: Mandatory
     */
    byte ACTION_ALWAYS_JOIN = 3;

    /** 
     * If there is a transaction available, then use it, otherwise continue processing 
     * <p>
     * J2EE: Supports
     */
    byte ACTION_JOIN_IF_POSSIBLE = 4;

    /**
     * There must not be a transaction present for the invocation
     * <p>
     * J2EE Never
     */
    byte ACTION_NEVER = 5;

    /**
     * Be indifferent to any active transaction.  Don;t check for one, and if there is one, don;t commit or abort it
     * <p>
     */
    byte ACTION_INDIFFERENT = 6;

    /*
     * Executes outside any existent transaction
     */
    byte ACTION_NOT_SUPPORTED = 7;

    /**
     * Transaction action by default.  Note that before 3.2 it was ACTION_NONE
     * <p>
     */
    byte ACTION_DEFAULT = ACTION_INDIFFERENT;
    
    TransactionFactory getFactory();

    void setFactory(TransactionFactory factory);

    byte getAction();

    void setAction(byte action);

    boolean isTransacted();

    ConstraintFilter getConstraint();

    void setConstraint(ConstraintFilter constraint);

    void setTimeout(int timeout);

    int getTimeout();

    boolean isInteractWithExternal();

    void setInteractWithExternal(boolean interactWithExternal);
    
    boolean isConfigured();
}
