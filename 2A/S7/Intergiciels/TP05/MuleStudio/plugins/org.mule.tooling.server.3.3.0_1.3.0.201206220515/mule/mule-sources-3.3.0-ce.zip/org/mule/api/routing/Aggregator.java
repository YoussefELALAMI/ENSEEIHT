/*
 * $Id: Aggregator.java 21641 2011-03-31 01:43:45Z tcarlson $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package org.mule.api.routing;

import org.mule.api.MessagingException;

public interface Aggregator
{

    void setTimeout(long timeout);

    void setFailOnTimeout(boolean failOnTimeout);

    void expireAggregation(String groupId) throws MessagingException;

}
