/*
 * $Id: Authentication.java 23743 2012-01-28 05:23:23Z dirk.olmes $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package org.mule.api.security;

import org.mule.api.MuleEvent;

import java.io.Serializable;
import java.util.Map;

/**
 * <code>Authentication</code> represents an authentication request and contains
 * authentication information if the request was successful
 */
public interface Authentication extends Serializable
{
    void setAuthenticated(boolean b);

    boolean isAuthenticated();

    Object getCredentials();

    Object getPrincipal();

    Map<String, Object> getProperties();

    void setProperties(Map<String, Object> properties);

    MuleEvent getEvent();
}
