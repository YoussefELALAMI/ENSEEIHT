/*
 * $Id: AbstractComponentTestCase.java 22377 2011-07-11 12:41:42Z dirk.olmes $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package org.mule.component;

import org.mule.tck.junit4.AbstractMuleContextTestCase;

public abstract class AbstractComponentTestCase extends AbstractMuleContextTestCase
{

}


