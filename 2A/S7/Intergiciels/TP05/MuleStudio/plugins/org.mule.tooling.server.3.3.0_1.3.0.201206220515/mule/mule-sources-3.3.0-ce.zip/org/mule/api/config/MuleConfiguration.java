/*
 * $Id: MuleConfiguration.java 24450 2012-05-29 19:39:09Z dfeist $
 * --------------------------------------------------------------------------------------
 *
 * (c) 2003-2010 MuleSoft, Inc. This software is protected under international copyright
 * law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 * (or other master license agreement) separately entered into in writing between you and
 * MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package org.mule.api.config;

/**
 * Configuration info. which can be set when creating the MuleContext but becomes
 * immutable after startup.
 */
public interface MuleConfiguration
{
    int getDefaultResponseTimeout();

    String getWorkingDirectory();

    String getMuleHomeDirectory();

    int getDefaultTransactionTimeout();

    boolean isClientMode();

    String getDefaultEncoding();

    String getId();

    String getDomainId();

    String getSystemModelType();

    String getSystemName();

    boolean isAutoWrapMessageAwareTransform();

    boolean isCacheMessageAsBytes();

    boolean isCacheMessageOriginalPayload();

    boolean isEnableStreaming();

    boolean isValidateExpressions();

    int getDefaultQueueTimeout();

    int getShutdownTimeout();

    /**
     * A container mode implies multiple Mule apps running. When true, Mule changes behavior in some areas, e.g.:
     * <ul>
     *     <li>Splash screens</li>
     *     <li>Thread names have app name in the prefix to guarantee uniqueness</li>
     * </ul>
     * etc.
     *
     * Note that e.g. a WAR-embedded Mule will run in container mode, but will still be considerd embedded
     * for management purposes.
     *
     * @see #isStandalone()
     */
    boolean isContainerMode();

    /**
     * Try to guess if we're embedded. If "mule.home" JVM property has been set, then we've been
     * started via Mule script and can assume we're running standalone. Otherwise (no property set), Mule
     * has been started via a different mechanism.
     * <p/>
     * A standalone Mule is always considered running in 'container' mode.
     *
     * @see #isContainerMode()
     */
    boolean isStandalone();

    /**
     * @return default exception strategy to be used on flows and services if there's no exception strategy
     * configured explicitly.
     */
    String getDefaultExceptionStrategyName();

    boolean useExtendedTransformations();

    boolean isFlowEndingWithOneWayEndpointReturnsNull();
    
    boolean isEnricherPropagatesSessionVariableChanges();

}
