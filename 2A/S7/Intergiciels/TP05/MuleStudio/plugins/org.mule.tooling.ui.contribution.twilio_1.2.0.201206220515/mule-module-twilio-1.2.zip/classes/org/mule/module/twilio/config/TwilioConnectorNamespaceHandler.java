
package org.mule.module.twilio.config;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;


/**
 * Registers bean definitions parsers for handling elements in <code>http://www.mulesoft.org/schema/mule/twilio</code>.
 * 
 */
public class TwilioConnectorNamespaceHandler
    extends NamespaceHandlerSupport
{


    /**
     * Invoked by the {@link DefaultBeanDefinitionDocumentReader} after construction but before any custom elements are parsed. 
     * @see NamespaceHandlerSupport#registerBeanDefinitionParser(String, BeanDefinitionParser)
     * 
     */
    public void init() {
        registerBeanDefinitionParser("config", new TwilioConnectorConfigDefinitionParser());
        registerBeanDefinitionParser("get-account-details", new GetAccountDetailsDefinitionParser());
        registerBeanDefinitionParser("get-all-accounts-details", new GetAllAccountsDetailsDefinitionParser());
        registerBeanDefinitionParser("update-account", new UpdateAccountDefinitionParser());
        registerBeanDefinitionParser("create-sub-account", new CreateSubAccountDefinitionParser());
        registerBeanDefinitionParser("get-sub-account-by-account-sid", new GetSubAccountByAccountSidDefinitionParser());
        registerBeanDefinitionParser("get-sub-account-by-friendly-name", new GetSubAccountByFriendlyNameDefinitionParser());
        registerBeanDefinitionParser("exchange-phone-numbers-between-subaccounts", new ExchangePhoneNumbersBetweenSubaccountsDefinitionParser());
        registerBeanDefinitionParser("get-available-phone-numbers", new GetAvailablePhoneNumbersDefinitionParser());
        registerBeanDefinitionParser("get-available-phone-numbers-advanced-seach", new GetAvailablePhoneNumbersAdvancedSeachDefinitionParser());
        registerBeanDefinitionParser("get-available-toll-free-numbers", new GetAvailableTollFreeNumbersDefinitionParser());
        registerBeanDefinitionParser("get-outgoing-caller-id-by-outgoing-caller-id-sid", new GetOutgoingCallerIdByOutgoingCallerIdSidDefinitionParser());
        registerBeanDefinitionParser("update-outgoing-caller-id-by-outgoing-caller-id-sid", new UpdateOutgoingCallerIdByOutgoingCallerIdSidDefinitionParser());
        registerBeanDefinitionParser("get-all-outgoing-caller-ids", new GetAllOutgoingCallerIdsDefinitionParser());
        registerBeanDefinitionParser("add-new-caller-id", new AddNewCallerIdDefinitionParser());
        registerBeanDefinitionParser("delete-outgoing-caller-id", new DeleteOutgoingCallerIdDefinitionParser());
        registerBeanDefinitionParser("get-incoming-phone-numbers-by-incoming-phone-number-sid", new GetIncomingPhoneNumbersByIncomingPhoneNumberSidDefinitionParser());
        registerBeanDefinitionParser("update-incoming-phone-numbers", new UpdateIncomingPhoneNumbersDefinitionParser());
        registerBeanDefinitionParser("delete-incoming-phone-number", new DeleteIncomingPhoneNumberDefinitionParser());
        registerBeanDefinitionParser("get-incoming-phone-numbers", new GetIncomingPhoneNumbersDefinitionParser());
        registerBeanDefinitionParser("add-incoming-phone-number-by-phone-number", new AddIncomingPhoneNumberByPhoneNumberDefinitionParser());
        registerBeanDefinitionParser("add-incoming-phone-number-by-area-code", new AddIncomingPhoneNumberByAreaCodeDefinitionParser());
        registerBeanDefinitionParser("get-application", new GetApplicationDefinitionParser());
        registerBeanDefinitionParser("update-application", new UpdateApplicationDefinitionParser());
        registerBeanDefinitionParser("delete-application", new DeleteApplicationDefinitionParser());
        registerBeanDefinitionParser("get-all-applications", new GetAllApplicationsDefinitionParser());
        registerBeanDefinitionParser("create-application", new CreateApplicationDefinitionParser());
        registerBeanDefinitionParser("get-call", new GetCallDefinitionParser());
        registerBeanDefinitionParser("get-calls", new GetCallsDefinitionParser());
        registerBeanDefinitionParser("make-call", new MakeCallDefinitionParser());
        registerBeanDefinitionParser("change-call-state", new ChangeCallStateDefinitionParser());
        registerBeanDefinitionParser("get-conference", new GetConferenceDefinitionParser());
        registerBeanDefinitionParser("get-conferences", new GetConferencesDefinitionParser());
        registerBeanDefinitionParser("get-participant", new GetParticipantDefinitionParser());
        registerBeanDefinitionParser("update-participant-status", new UpdateParticipantStatusDefinitionParser());
        registerBeanDefinitionParser("delete-participant", new DeleteParticipantDefinitionParser());
        registerBeanDefinitionParser("get-participants", new GetParticipantsDefinitionParser());
        registerBeanDefinitionParser("get-sms-message", new GetSmsMessageDefinitionParser());
        registerBeanDefinitionParser("get-all-sms-messages", new GetAllSmsMessagesDefinitionParser());
        registerBeanDefinitionParser("send-sms-message", new SendSmsMessageDefinitionParser());
        registerBeanDefinitionParser("get-recording", new GetRecordingDefinitionParser());
        registerBeanDefinitionParser("delete-recording", new DeleteRecordingDefinitionParser());
        registerBeanDefinitionParser("get-recordings", new GetRecordingsDefinitionParser());
        registerBeanDefinitionParser("get-transcription-by-transcription-sid", new GetTranscriptionByTranscriptionSidDefinitionParser());
        registerBeanDefinitionParser("get-transcriptions", new GetTranscriptionsDefinitionParser());
        registerBeanDefinitionParser("get-notification", new GetNotificationDefinitionParser());
        registerBeanDefinitionParser("delete-notification", new DeleteNotificationDefinitionParser());
        registerBeanDefinitionParser("get-all-notifications", new GetAllNotificationsDefinitionParser());
        registerBeanDefinitionParser("get-notifications-by-call-sid", new GetNotificationsByCallSidDefinitionParser());
        registerBeanDefinitionParser("get-sandbox", new GetSandboxDefinitionParser());
        registerBeanDefinitionParser("update-sandbox", new UpdateSandboxDefinitionParser());
    }

}
