
package org.mule.module.twilio.config;

import org.apache.commons.lang.StringUtils;
import org.mule.api.lifecycle.Disposable;
import org.mule.api.lifecycle.Initialisable;
import org.mule.config.spring.MuleHierarchicalBeanDefinitionParserDelegate;
import org.mule.config.spring.parsers.generic.AutoIdUtils;
import org.mule.module.twilio.adapters.TwilioConnectorHttpCallbackAdapter;
import org.mule.util.TemplateParser;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class TwilioConnectorConfigDefinitionParser
    implements BeanDefinitionParser
{

    /**
     * Mule Pattern Info
     * 
     */
    private TemplateParser.PatternInfo patternInfo;

    public TwilioConnectorConfigDefinitionParser() {
        patternInfo = TemplateParser.createMuleStyleParser().getStyle();
    }

    public BeanDefinition parse(Element element, ParserContext parserContent) {
        String name = element.getAttribute("name");
        if ((name == null)||StringUtils.isBlank(name)) {
            element.setAttribute("name", AutoIdUtils.getUniqueName(element, "mule-bean"));
        }
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(TwilioConnectorHttpCallbackAdapter.class.getName());
        if (Initialisable.class.isAssignableFrom(TwilioConnectorHttpCallbackAdapter.class)) {
            builder.setInitMethodName(Initialisable.PHASE_NAME);
        }
        if (Disposable.class.isAssignableFrom(TwilioConnectorHttpCallbackAdapter.class)) {
            builder.setDestroyMethodName(Disposable.PHASE_NAME);
        }
        if ((element.getAttribute("accountSid")!= null)&&(!StringUtils.isBlank(element.getAttribute("accountSid")))) {
            builder.addPropertyValue("accountSid", element.getAttribute("accountSid"));
        }
        if ((element.getAttribute("authToken")!= null)&&(!StringUtils.isBlank(element.getAttribute("authToken")))) {
            builder.addPropertyValue("authToken", element.getAttribute("authToken"));
        }
        Element httpCallbackConfigElement = DomUtils.getChildElementByTagName(element, "http-callback-config");
        if (httpCallbackConfigElement!= null) {
            if ((httpCallbackConfigElement.getAttribute("domain")!= null)&&(!StringUtils.isBlank(httpCallbackConfigElement.getAttribute("domain")))) {
                builder.addPropertyValue("domain", httpCallbackConfigElement.getAttribute("domain"));
            }
            if ((httpCallbackConfigElement.getAttribute("localPort")!= null)&&(!StringUtils.isBlank(httpCallbackConfigElement.getAttribute("localPort")))) {
                builder.addPropertyValue("localPort", httpCallbackConfigElement.getAttribute("localPort"));
            }
            if ((httpCallbackConfigElement.getAttribute("remotePort")!= null)&&(!StringUtils.isBlank(httpCallbackConfigElement.getAttribute("remotePort")))) {
                builder.addPropertyValue("remotePort", httpCallbackConfigElement.getAttribute("remotePort"));
            }
            if ((httpCallbackConfigElement.getAttribute("async")!= null)&&(!StringUtils.isBlank(httpCallbackConfigElement.getAttribute("async")))) {
                builder.addPropertyValue("async", httpCallbackConfigElement.getAttribute("async"));
            }
            if ((httpCallbackConfigElement.getAttribute("connector-ref")!= null)&&(!StringUtils.isBlank(httpCallbackConfigElement.getAttribute("connector-ref")))) {
                builder.addPropertyValue("connector", new RuntimeBeanReference(httpCallbackConfigElement.getAttribute("connector-ref")));
            }
        }
        BeanDefinition definition = builder.getBeanDefinition();
        definition.setAttribute(MuleHierarchicalBeanDefinitionParserDelegate.MULE_NO_RECURSE, Boolean.TRUE);
        return definition;
    }

}
